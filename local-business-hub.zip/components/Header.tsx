"use client"

import Link from "next/link"
import Logo from "./Logo"
import { useAuth } from "@/lib/auth"
import { useState } from "react"
import { Menu, X } from "lucide-react"

export default function Header() {
  const { user, logout } = useAuth()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center space-x-2">
            <Logo className="w-10 h-10" />
            <span className="text-2xl font-bold text-green-700">Hamro Kirana</span>
          </Link>
          <nav className="hidden md:block">
            <ul className="flex space-x-6">
              <li>
                <Link href="/shops" className="text-gray-600 hover:text-green-500">
                  Shops
                </Link>
              </li>
              <li>
                <Link href="/products" className="text-gray-600 hover:text-green-500">
                  Products
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-600 hover:text-green-500">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-600 hover:text-green-500">
                  Contact
                </Link>
              </li>
            </ul>
          </nav>
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <>
                <span>Welcome, {user.name}</span>
                <Link href="/dashboard" className="text-green-500 hover:text-green-700">
                  Dashboard
                </Link>
                {user.isSeller && (
                  <Link href="/seller-dashboard" className="text-green-500 hover:text-green-700">
                    Seller Dashboard
                  </Link>
                )}
                <button onClick={logout} className="bg-green-500 text-white px-4 py-2 rounded">
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="text-green-500 hover:text-green-700">
                  Login
                </Link>
                <Link href="/register" className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600">
                  Register
                </Link>
              </>
            )}
          </div>
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden">
          <nav className="px-4 pt-2 pb-4">
            <ul className="space-y-2">
              <li>
                <Link href="/shops" className="block text-gray-600 hover:text-green-500">
                  Shops
                </Link>
              </li>
              <li>
                <Link href="/products" className="block text-gray-600 hover:text-green-500">
                  Products
                </Link>
              </li>
              <li>
                <Link href="/about" className="block text-gray-600 hover:text-green-500">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="block text-gray-600 hover:text-green-500">
                  Contact
                </Link>
              </li>
              {user ? (
                <>
                  <li>
                    <Link href="/dashboard" className="block text-green-500 hover:text-green-700">
                      Dashboard
                    </Link>
                  </li>
                  {user.isSeller && (
                    <li>
                      <Link href="/seller-dashboard" className="block text-green-500 hover:text-green-700">
                        Seller Dashboard
                      </Link>
                    </li>
                  )}
                  <li>
                    <button
                      onClick={logout}
                      className="block w-full text-left bg-green-500 text-white px-4 py-2 rounded"
                    >
                      Logout
                    </button>
                  </li>
                </>
              ) : (
                <>
                  <li>
                    <Link href="/login" className="block text-green-500 hover:text-green-700">
                      Login
                    </Link>
                  </li>
                  <li>
                    <Link
                      href="/register"
                      className="block bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
                    >
                      Register
                    </Link>
                  </li>
                </>
              )}
            </ul>
          </nav>
        </div>
      )}
    </header>
  )
}

