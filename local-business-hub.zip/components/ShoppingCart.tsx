"use client"

import { useState } from "react"
import { ShoppingCartIcon as CartIcon, X, Plus, Minus } from "lucide-react"
import Link from "next/link"
import { useCart } from "@/lib/cart"

export default function ShoppingCart() {
  const [isOpen, setIsOpen] = useState(false)
  const { cart, removeFromCart, updateQuantity } = useCart()

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)

  return (
    <div className="fixed bottom-4 right-4">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-green-500 text-white p-4 rounded-full shadow-lg hover:bg-green-600 transition-colors"
      >
        <CartIcon />
        <span className="ml-2">{cart.length}</span>
      </button>

      {isOpen && (
        <div className="absolute bottom-16 right-0 w-80 bg-white rounded-lg shadow-xl p-4">
          <h3 className="text-lg font-semibold mb-2">Your Cart</h3>
          {cart.length === 0 ? (
            <p>Your cart is empty</p>
          ) : (
            <>
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between items-center mb-2">
                  <div>
                    <span className="font-medium">{item.name}</span>
                    <div className="flex items-center mt-1">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        <Minus size={16} />
                      </button>
                      <span className="mx-2">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        <Plus size={16} />
                      </button>
                    </div>
                  </div>
                  <div className="text-right">
                    <span>Rs. {(item.price * item.quantity).toFixed(2)}</span>
                    <button onClick={() => removeFromCart(item.id)} className="text-red-500 ml-2">
                      <X size={16} />
                    </button>
                  </div>
                </div>
              ))}
              <div className="mt-4 pt-2 border-t border-gray-200">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Total:</span>
                  <span>Rs. {total.toFixed(2)}</span>
                </div>
              </div>
              <Link
                href="/checkout"
                className="mt-4 block w-full bg-green-500 text-white py-2 px-4 rounded text-center hover:bg-green-600 transition-colors"
              >
                Proceed to Checkout
              </Link>
            </>
          )}
        </div>
      )}
    </div>
  )
}

