import { ShoppingBasket } from "lucide-react"

export default function Logo({ className = "w-6 h-6" }) {
  return (
    <div className={`${className} bg-green-500 text-white rounded-full p-1`}>
      <ShoppingBasket />
    </div>
  )
}

