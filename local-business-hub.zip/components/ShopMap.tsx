"use client"

import { useEffect, useRef } from "react"
import L from "leaflet"
import "leaflet/dist/leaflet.css"

type Shop = {
  id: number | string
  name: string
  location?: {
    lat: number
    lon: number
  }
}

type ShopMapProps = {
  shops: Shop[]
  selectedShop?: number | string
}

export default function ShopMap({ shops, selectedShop }: ShopMapProps) {
  const mapRef = useRef<L.Map | null>(null)
  const defaultCenter = [27.6838, 83.4333] // Default center for Butwal, Nepal

  useEffect(() => {
    if (typeof window !== "undefined") {
      if (!mapRef.current) {
        mapRef.current = L.map("map").setView(defaultCenter, 13)
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        }).addTo(mapRef.current)
      }

      shops.forEach((shop) => {
        if (shop.location && typeof shop.location.lat === "number" && typeof shop.location.lon === "number") {
          const marker = L.marker([shop.location.lat, shop.location.lon]).addTo(mapRef.current!).bindPopup(shop.name)

          if (shop.id === selectedShop) {
            marker.openPopup()
            mapRef.current?.setView([shop.location.lat, shop.location.lon], 15)
          }
        }
      })
    }

    return () => {
      if (mapRef.current) {
        mapRef.current.remove()
        mapRef.current = null
      }
    }
  }, [shops, selectedShop])

  return <div id="map" style={{ height: "400px", width: "100%" }} />
}

