import Link from "next/link"
import Logo from "./Logo"

export default function Footer() {
  return (
    <footer className="bg-green-700 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="flex flex-col items-center md:items-start">
            <Logo className="w-12 h-12 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Hamro Kirana</h3>
            <p className="text-green-100 text-center md:text-left">
              Connecting you with local grocery shops in Butwal.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/shops" className="text-green-100 hover:text-white">
                  Find Shops
                </Link>
              </li>
              <li>
                <Link href="/deals" className="text-green-100 hover:text-white">
                  Today's Deals
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-green-100 hover:text-white">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-green-100 hover:text-white">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">For Shop Owners</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/register" className="text-green-100 hover:text-white">
                  Register Your Shop
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="text-green-100 hover:text-white">
                  Seller Dashboard
                </Link>
              </li>
              <li>
                <Link href="/help" className="text-green-100 hover:text-white">
                  Seller Help Center
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Connect With Us</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-green-100 hover:text-white">
                  Facebook
                </a>
              </li>
              <li>
                <a href="#" className="text-green-100 hover:text-white">
                  Instagram
                </a>
              </li>
              <li>
                <a href="#" className="text-green-100 hover:text-white">
                  Twitter
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-green-600 text-center">
          <p className="text-green-100">&copy; 2023 Hamro Kirana. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

