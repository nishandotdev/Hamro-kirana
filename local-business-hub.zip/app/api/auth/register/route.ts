import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import bcrypt from "bcryptjs"
import { generateToken } from "@/lib/auth"

export async function POST(req: Request) {
  try {
    const { name, email, password } = await req.json()
    const hashedPassword = await bcrypt.hash(password, 10)
    const user = await db.createUser(name, email, hashedPassword)
    const token = await generateToken({ id: user.id, name: user.name, email: user.email })
    return NextResponse.json({ token, user: { id: user.id, name: user.name, email: user.email } })
  } catch (error) {
    return NextResponse.json({ error: "Registration failed" }, { status: 400 })
  }
}

