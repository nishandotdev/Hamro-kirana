import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import bcrypt from "bcryptjs"
import { generateToken } from "@/lib/auth"

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json()
    const user = await db.getUser(email)
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }
    const token = await generateToken({
      id: user.id,
      name: user.name,
      email: user.email,
      isSeller: user.isSeller,
      isAdmin: user.isAdmin,
    })
    return NextResponse.json({
      token,
      user: { id: user.id, name: user.name, email: user.email, isSeller: user.isSeller, isAdmin: user.isAdmin },
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Login failed" }, { status: 400 })
  }
}

