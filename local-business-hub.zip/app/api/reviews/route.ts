import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function POST(req: Request) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }
    const decoded = jwt.verify(token, JWT_SECRET) as { id: string; name: string; email: string }
    const { productId, rating, comment } = await req.json()
    const review = await db.createReview(decoded.id, productId, rating, comment)
    return NextResponse.json({ review })
  } catch (error) {
    console.error("Review creation error:", error)
    return NextResponse.json({ error: "Review creation failed" }, { status: 400 })
  }
}

export async function GET(req: Request) {
  try {
    const url = new URL(req.url)
    const productId = Number.parseInt(url.searchParams.get("productId") || "")
    if (isNaN(productId)) {
      return NextResponse.json({ error: "Invalid product ID" }, { status: 400 })
    }
    const reviews = await db.getReviews(productId)
    return NextResponse.json({ reviews })
  } catch (error) {
    console.error("Fetch reviews error:", error)
    return NextResponse.json({ error: "Failed to fetch reviews" }, { status: 400 })
  }
}

