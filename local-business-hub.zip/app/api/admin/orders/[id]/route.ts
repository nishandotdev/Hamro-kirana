import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "123bdd81643dcec70234cfac4c123fffaedf6431b17c803f2c5db688549126931d5c93c"

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = jwt.verify(token, JWT_SECRET) as { id: string; isAdmin: boolean }
    if (!decoded.isAdmin) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const { status } = await req.json()
    const order = await db.updateOrderStatus(params.id, status)
    return NextResponse.json({ order })
  } catch (error) {
    return NextResponse.json({ error: "Failed to update order" }, { status: 400 })
  }
}

