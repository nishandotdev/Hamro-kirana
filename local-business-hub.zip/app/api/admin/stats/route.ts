import { NextResponse } from "next/server"
import { db } from "@/lib/db"
import jwt from "jsonwebtoken"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function GET(req: Request) {
  try {
    const token = req.headers.get("Authorization")?.split(" ")[1]
    if (!token) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const decoded = jwt.verify(token, JWT_SECRET) as { id: string; isAdmin: boolean }
    if (!decoded.isAdmin) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const orders = await db.getAllOrders()
    const totalOrders = orders.length
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0)
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0

    return NextResponse.json({
      totalOrders,
      totalRevenue,
      averageOrderValue,
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 400 })
  }
}

