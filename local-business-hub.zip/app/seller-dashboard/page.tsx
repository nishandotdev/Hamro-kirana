"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth"
import Link from "next/link"
import Image from "next/image"

type Shop = {
  id: string
  name: string
  description: string
  image: string
}

type Product = {
  id: string
  name: string
  price: number
  stock: number
  image: string
}

export default function SellerDashboardPage() {
  const { user } = useAuth()
  const [shops, setShops] = useState<Shop[]>([])
  const [products, setProducts] = useState<Product[]>([])

  useEffect(() => {
    if (user) {
      fetchShops()
      fetchProducts()
    }
  }, [user])

  const fetchShops = async () => {
    try {
      const response = await fetch("/api/seller/shops", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      })
      if (response.ok) {
        const data = await response.json()
        setShops(data.shops)
      }
    } catch (error) {
      console.error("Error fetching shops:", error)
    }
  }

  const fetchProducts = async () => {
    try {
      const response = await fetch("/api/seller/products", {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      })
      if (response.ok) {
        const data = await response.json()
        setProducts(data.products)
      }
    } catch (error) {
      console.error("Error fetching products:", error)
    }
  }

  if (!user) {
    return <div>Please log in to access the seller dashboard.</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Seller Dashboard</h1>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4">Your Shops</h2>
        {shops.length === 0 ? (
          <p>You haven't created any shops yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {shops.map((shop) => (
              <div key={shop.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <Image
                  src={shop.image || "https://picsum.photos/seed/shop/300/200"}
                  alt={shop.name}
                  width={300}
                  height={200}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-xl font-semibold mb-2">{shop.name}</h3>
                  <p className="text-gray-600 mb-4">{shop.description}</p>
                  <Link href={`/seller-dashboard/shops/${shop.id}`} className="text-green-500 hover:text-green-600">
                    Manage Shop
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
        <Link
          href="/seller-dashboard/create-shop"
          className="mt-4 inline-block bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
        >
          Create New Shop
        </Link>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Your Products</h2>
        {products.length === 0 ? (
          <p>You haven't added any products yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {products.map((product) => (
              <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <Image
                  src={product.image || "https://picsum.photos/seed/product/300/200"}
                  alt={product.name}
                  width={300}
                  height={200}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4">
                  <h3 className="text-lg font-semibold mb-2">{product.name}</h3>
                  <p className="text-gray-600 mb-2">Price: Rs. {product.price.toFixed(2)}</p>
                  <p className="text-gray-600 mb-4">Stock: {product.stock}</p>
                  <Link
                    href={`/seller-dashboard/products/${product.id}`}
                    className="text-green-500 hover:text-green-600"
                  >
                    Edit Product
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
        <Link
          href="/seller-dashboard/create-product"
          className="mt-4 inline-block bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
        >
          Add New Product
        </Link>
      </section>
    </div>
  )
}

