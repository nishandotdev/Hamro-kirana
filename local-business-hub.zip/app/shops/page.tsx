"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Search } from "lucide-react"
import ShopMap from "@/components/ShopMap"

const shops = [
  { id: 1, name: "Fresh Harvest Kirana", category: "Organic Produce", image: "/organic-shop.jpg" },
  { id: 2, name: "Spice Paradise", category: "Spices & Condiments", image: "/spice-shop.jpg" },
  { id: 3, name: "Green Leaf Grocers", category: "Fresh Vegetables", image: "/vegetable-shop.jpg" },
  { id: 4, name: "Daily Needs Store", category: "General Grocery", image: "/general-store.jpg" },
  { id: 5, name: "Fruit Haven", category: "Fresh Fruits", image: "/fruit-shop.jpg" },
  { id: 6, name: "Dairy Delight", category: "Dairy Products", image: "/dairy-shop.jpg" },
]

export default function ShopsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [selectedShop, setSelectedShop] = useState<number | undefined>(undefined)

  const categories = Array.from(new Set(shops.map((shop) => shop.category)))

  const filteredShops = shops.filter(
    (shop) =>
      shop.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
      (selectedCategory === "" || shop.category === selectedCategory),
  )

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-green-700">Local Grocery Shops</h1>
      <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
        <div className="relative mb-4 md:mb-0 md:w-1/3">
          <input
            type="text"
            placeholder="Search shops..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
        </div>
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
        >
          <option value="">All Categories</option>
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredShops.map((shop) => (
              <Link href={`/shops/${shop.id}`} key={shop.id}>
                <div
                  className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow cursor-pointer transform hover:scale-105 transition-transform duration-200"
                  onMouseEnter={() => setSelectedShop(shop.id)}
                  onMouseLeave={() => setSelectedShop(undefined)}
                >
                  <Image
                    src={shop.image || "/placeholder.svg"}
                    alt={shop.name}
                    width={300}
                    height={200}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <h3 className="text-xl font-semibold mb-1 text-green-700">{shop.name}</h3>
                    <p className="text-gray-600">{shop.category}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
        <div className="lg:col-span-1">
          <div className="sticky top-8">
            <ShopMap shops={shops} selectedShop={selectedShop} />
          </div>
        </div>
      </div>
    </div>
  )
}

