"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import { notFound } from "next/navigation"
import { useCart } from "@/lib/cart"
import { useAuth } from "@/lib/auth"
import { useWishlist } from "@/lib/wishlist"
import { Star, Heart, ShoppingCart } from "lucide-react"

const shops = [
  {
    id: 1,
    name: "Fresh Harvest Kirana",
    category: "Organic Produce",
    image: "/organic-shop.jpg",
    description: "We offer the freshest organic produce sourced directly from local farmers.",
    products: [
      { id: 1, name: "Organic Tomatoes", price: 2.99, image: "/tomatoes.jpg" },
      { id: 2, name: "Organic Spinach", price: 1.99, image: "/spinach.jpg" },
      { id: 3, name: "Organic Carrots", price: 1.49, image: "/carrots.jpg" },
    ],
    location: { lat: 27.68, lon: 83.43 },
  },
  {
    id: 2,
    name: "Spice Paradise",
    category: "Spices & Condiments",
    image: "/spice-shop.jpg",
    description: "Discover a world of flavors with our wide range of spices and condiments.",
    products: [
      { id: 4, name: "Turmeric Powder", price: 3.99, image: "/turmeric.jpg" },
      { id: 5, name: "Cinnamon Sticks", price: 4.99, image: "/cinnamon.jpg" },
      { id: 6, name: "Cumin Seeds", price: 2.99, image: "/cumin.jpg" },
    ],
    location: { lat: 27.685, lon: 83.435 },
  },
  {
    id: 3,
    name: "Green Leaf Grocers",
    category: "Fresh Vegetables",
    image: "/vegetable-shop.jpg",
    description: "Your one-stop shop for farm-fresh vegetables and greens.",
    products: [
      { id: 7, name: "Lettuce", price: 1.99, image: "/lettuce.jpg" },
      { id: 8, name: "Broccoli", price: 2.49, image: "/broccoli.jpg" },
      { id: 9, name: "Bell Peppers", price: 2.99, image: "/bell-peppers.jpg" },
    ],
    location: { lat: 27.69, lon: 83.44 },
  },
  {
    id: 4,
    name: "Daily Needs Store",
    category: "General Grocery",
    image: "/general-store.jpg",
    description: "We stock all your daily essentials and household items.",
    products: [
      { id: 10, name: "Milk", price: 3.49, image: "/milk.jpg" },
      { id: 11, name: "Bread", price: 2.49, image: "/bread.jpg" },
      { id: 12, name: "Eggs", price: 3.99, image: "/eggs.jpg" },
    ],
    location: { lat: 27.695, lon: 83.445 },
  },
  {
    id: 5,
    name: "Fruit Haven",
    category: "Fresh Fruits",
    image: "/fruit-shop.jpg",
    description: "Indulge in nature's sweetness with our selection of fresh, seasonal fruits.",
    products: [
      { id: 13, name: "Apples", price: 2.99, image: "/apples.jpg" },
      { id: 14, name: "Bananas", price: 0.99, image: "/bananas.jpg" },
      { id: 15, name: "Oranges", price: 1.99, image: "/oranges.jpg" },
    ],
    location: { lat: 27.7, lon: 83.45 },
  },
  {
    id: 6,
    name: "Dairy Delight",
    category: "Dairy Products",
    image: "/dairy-shop.jpg",
    description: "From farm-fresh milk to artisanal cheeses, we have all your dairy needs covered.",
    products: [
      { id: 16, name: "Cheese", price: 4.99, image: "/cheese.jpg" },
      { id: 17, name: "Yogurt", price: 2.49, image: "/yogurt.jpg" },
      { id: 18, name: "Butter", price: 3.99, image: "/butter.jpg" },
    ],
    location: { lat: 27.705, lon: 83.455 },
  },
  {
    id: 7,
    name: "Bakery Bliss",
    category: "Bakery",
    image: "/bakery-shop.jpg",
    description: "Freshly baked bread, pastries, and cakes made with love.",
    products: [
      { id: 19, name: "Whole Wheat Bread", price: 2.99, image: "/wheat-bread.jpg" },
      { id: 20, name: "Chocolate Croissant", price: 1.99, image: "/chocolate-croissant.jpg" },
      { id: 21, name: "Blueberry Muffins", price: 3.99, image: "/blueberry-muffins.jpg" },
    ],
    location: { lat: 27.6839, lon: 83.4369 },
  },
  {
    id: 8,
    name: "Snack Shack",
    category: "Snacks & Beverages",
    image: "/snack-shop.jpg",
    description: "Your go-to place for quick bites and refreshing drinks.",
    products: [
      { id: 22, name: "Potato Chips", price: 1.49, image: "/potato-chips.jpg" },
      { id: 23, name: "Cola", price: 0.99, image: "/cola.jpg" },
      { id: 24, name: "Mixed Nuts", price: 3.99, image: "/mixed-nuts.jpg" },
    ],
    location: { lat: 27.681, lon: 83.4407 },
  },
  {
    id: 9,
    name: "Health Hub",
    category: "Health Foods",
    image: "/health-shop.jpg",
    description: "Nutritious and organic options for health-conscious individuals.",
    products: [
      { id: 25, name: "Quinoa", price: 4.99, image: "/quinoa.jpg" },
      { id: 26, name: "Chia Seeds", price: 3.99, image: "/chia-seeds.jpg" },
      { id: 27, name: "Green Tea", price: 2.99, image: "/green-tea.jpg" },
    ],
    location: { lat: 27.6868, lon: 83.4312 },
  },
]

shops.forEach((shop, index) => {
  if (!shop.location) {
    shop.location = {
      lat: 27.68 + index * 0.005,
      lon: 83.43 + index * 0.005,
    }
  }
})

type Review = {
  id: string
  userId: string
  productId: number
  rating: number
  comment: string
  createdAt: string
}

export default function ShopPage({ params }: { params: { id: string } }) {
  const shop = shops.find((s) => s.id === Number.parseInt(params.id))
  const { addToCart } = useCart()
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist()
  const { user } = useAuth()
  const [reviews, setReviews] = useState<Record<number, Review[]>>({})
  const [newReview, setNewReview] = useState({ productId: 0, rating: 0, comment: "" })

  useEffect(() => {
    if (shop) {
      shop.products.forEach((product) => {
        fetchReviews(product.id)
      })
    }
  }, [shop])

  const fetchReviews = async (productId: number) => {
    try {
      const response = await fetch(`/api/reviews?productId=${productId}`)
      if (!response.ok) {
        throw new Error("Failed to fetch reviews")
      }
      const data = await response.json()
      setReviews((prev) => ({ ...prev, [productId]: data.reviews }))
    } catch (error) {
      console.error("Error fetching reviews:", error)
    }
  }

  const handleAddReview = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) {
      alert("Please log in to leave a review")
      return
    }
    try {
      const token = localStorage.getItem("token")
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(newReview),
      })
      if (!response.ok) {
        throw new Error("Failed to add review")
      }
      fetchReviews(newReview.productId)
      setNewReview({ productId: 0, rating: 0, comment: "" })
    } catch (error) {
      console.error("Error adding review:", error)
    }
  }

  if (!shop) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8">
        <div className="md:flex">
          <div className="md:flex-shrink-0">
            <Image
              src={shop.image || "/placeholder.svg"}
              alt={shop.name}
              width={400}
              height={300}
              className="h-48 w-full object-cover md:h-full md:w-48"
            />
          </div>
          <div className="p-8">
            <div className="uppercase tracking-wide text-sm text-green-500 font-semibold">{shop.category}</div>
            <h1 className="mt-1 text-3xl font-bold text-green-700">{shop.name}</h1>
            <p className="mt-2 text-gray-600">{shop.description}</p>
          </div>
        </div>
      </div>

      <h2 className="text-2xl font-bold mb-4 text-green-700">Products</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {shop.products.map((product) => (
          <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="relative">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={300}
                height={200}
                className="w-full h-48 object-cover"
              />
              <button
                onClick={() => (isInWishlist(product.id) ? removeFromWishlist(product.id) : addToWishlist(product))}
                className="absolute top-2 right-2 p-2 bg-white rounded-full shadow-md hover:bg-gray-100 transition-colors"
              >
                <Heart
                  className={isInWishlist(product.id) ? "text-red-500" : "text-gray-400"}
                  fill={isInWishlist(product.id) ? "currentColor" : "none"}
                />
              </button>
            </div>
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
              <p className="text-gray-600 mb-4">Rs. {product.price.toFixed(2)}</p>
              <button
                onClick={() => addToCart(product)}
                className="w-full bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition-colors flex items-center justify-center"
              >
                <ShoppingCart className="mr-2" size={20} />
                Add to Cart
              </button>
              <div className="mt-4">
                <h4 className="font-semibold mb-2">Reviews</h4>
                {reviews[product.id]?.map((review) => (
                  <div key={review.id} className="mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={i < review.rating ? "text-yellow-400" : "text-gray-300"} size={16} />
                      ))}
                    </div>
                    <p className="text-sm text-gray-600">{review.comment}</p>
                  </div>
                ))}
                {user && (
                  <form onSubmit={handleAddReview} className="mt-2">
                    <select
                      value={newReview.rating}
                      onChange={(e) =>
                        setNewReview({ ...newReview, productId: product.id, rating: Number.parseInt(e.target.value) })
                      }
                      className="mb-2 p-1 border rounded"
                      required
                    >
                      <option value="">Select rating</option>
                      {[1, 2, 3, 4, 5].map((rating) => (
                        <option key={rating} value={rating}>
                          {rating} star{rating !== 1 ? "s" : ""}
                        </option>
                      ))}
                    </select>
                    <textarea
                      value={newReview.comment}
                      onChange={(e) => setNewReview({ ...newReview, productId: product.id, comment: e.target.value })}
                      className="w-full p-2 border rounded mb-2"
                      placeholder="Write your review"
                      required
                    />
                    <button type="submit" className="bg-green-500 text-white px-2 py-1 rounded text-sm">
                      Submit Review
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

