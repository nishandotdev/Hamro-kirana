import Link from "next/link"
import { Search, ShoppingBasket, Star, Tag } from "lucide-react"
import Image from "next/image"
import { db } from "@/lib/db"

export default async function Home() {
  const shops = await db.getAllShops()
  const products = await db.getAllProducts()

  return (
    <div className="container mx-auto px-4">
      <section className="py-16 text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-4 text-green-700">Welcome to Hamro Kirana</h1>
        <p className="text-lg md:text-xl mb-8 text-gray-600">
          Fresh groceries from local shops in Butwal, delivered to your doorstep
        </p>
        <Link
          href="/shops"
          className="bg-green-500 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-green-600 transition-colors shadow-lg inline-block"
        >
          Explore Local Shops
        </Link>
        <div className="mt-12">
          <Image
            src="https://picsum.photos/seed/hamrokirana/800/400"
            alt="Fresh groceries"
            width={800}
            height={400}
            className="rounded-lg shadow-xl mx-auto"
          />
        </div>
      </section>

      <section className="py-16 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl md:text-3xl font-semibold mb-8 text-center text-green-700">Why Choose Hamro Kirana?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <FeatureCard
            icon={<Search className="w-12 h-12 text-green-500" />}
            title="Find Local Shops"
            description="Discover grocery stores in your neighborhood."
          />
          <FeatureCard
            icon={<ShoppingBasket className="w-12 h-12 text-green-500" />}
            title="Online Ordering"
            description="Browse products and order from multiple stores."
          />
          <FeatureCard
            icon={<Star className="w-12 h-12 text-green-500" />}
            title="Quality Ratings"
            description="Read reviews and check freshness ratings."
          />
          <FeatureCard
            icon={<Tag className="w-12 h-12 text-green-500" />}
            title="Daily Deals"
            description="Get notified about special offers and discounts."
          />
        </div>
      </section>

      <section className="py-16">
        <h2 className="text-2xl md:text-3xl font-semibold mb-8 text-center text-green-700">Featured Local Shops</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {shops.slice(0, 3).map((shop) => (
            <ShopCard key={shop.id} name={shop.name} category={shop.description} image={shop.image} />
          ))}
        </div>
      </section>

      <section className="py-16">
        <h2 className="text-2xl md:text-3xl font-semibold mb-8 text-center text-green-700">Featured Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.slice(0, 8).map((product) => (
            <ProductCard key={product.id} name={product.name} price={product.price} image={product.image} />
          ))}
        </div>
      </section>
    </div>
  )
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="bg-gray-50 p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow">
      <div className="flex justify-center mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2 text-green-700">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  )
}

function ShopCard({ name, category, image }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow">
      <Image
        src={image || "https://picsum.photos/seed/shop/300/200"}
        alt={name}
        width={300}
        height={200}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-semibold mb-1 text-green-700">{name}</h3>
        <p className="text-gray-600">{category}</p>
      </div>
    </div>
  )
}

function ProductCard({ name, price, image }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow">
      <Image
        src={image || "https://picsum.photos/seed/product/300/200"}
        alt={name}
        width={300}
        height={200}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2 text-green-700">{name}</h3>
        <p className="text-gray-600">Rs. {price.toFixed(2)}</p>
      </div>
    </div>
  )
}

