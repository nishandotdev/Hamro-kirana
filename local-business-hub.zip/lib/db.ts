import { v4 as uuidv4 } from "uuid"

type User = {
  id: string
  name: string
  email: string
  password: string
  isAdmin: boolean
  isSeller: boolean
  createdAt: Date
  updatedAt: Date
}

type Shop = {
  id: string
  sellerId: string
  name: string
  description: string
  image: string
  location: {
    lat: number
    lon: number
  }
  createdAt: Date
  updatedAt: Date
}

type Product = {
  id: string
  shopId: string
  name: string
  description: string
  price: number
  stock: number
  category: string
  image: string
  createdAt: Date
  updatedAt: Date
}

type Order = {
  id: string
  userId: string
  shopId: string
  total: number
  status: "pending" | "processing" | "shipped" | "delivered"
  address: string
  createdAt: Date
  updatedAt: Date
}

type OrderItem = {
  id: string
  orderId: string
  productId: string
  quantity: number
  price: number
}

type Review = {
  id: string
  userId: string
  productId: string
  rating: number
  comment: string
  createdAt: Date
  updatedAt: Date
}

type Delivery = {
  id: string
  orderId: string
  status: "pending" | "in-transit" | "delivered"
  estimatedDeliveryTime: Date
  actualDeliveryTime: Date | null
  createdAt: Date
  updatedAt: Date
}

type Category = {
  id: string
  name: string
  description: string | null
}

type WishlistItem = {
  id: string
  userId: string
  productId: string
  createdAt: Date
}

type Coupon = {
  id: string
  code: string
  discountPercentage: number
  validFrom: Date
  validUntil: Date
  usageLimit: number
  usageCount: number
}

class DB {
  private users: User[] = []
  private shops: Shop[] = []
  private products: Product[] = []
  private orders: Order[] = []
  private orderItems: OrderItem[] = []
  private reviews: Review[] = []
  private deliveries: Delivery[] = []
  private categories: Category[] = []
  private wishlistItems: WishlistItem[] = []
  private coupons: Coupon[] = []

  async createUser(name: string, email: string, password: string, isAdmin = false, isSeller = false): Promise<User> {
    const user = {
      id: uuidv4(),
      name,
      email,
      password,
      isAdmin,
      isSeller,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.users.push(user)
    return user
  }

  async getUser(email: string): Promise<User | undefined> {
    return this.users.find((user) => user.email === email)
  }

  async createShop(
    sellerId: string,
    name: string,
    description: string,
    image: string,
    location: { lat: number; lon: number },
  ): Promise<Shop> {
    const shop: Shop = {
      id: uuidv4(),
      sellerId,
      name,
      description,
      image,
      location,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.shops.push(shop)
    return shop
  }

  async getShopsBySeller(sellerId: string): Promise<Shop[]> {
    return this.shops.filter((shop) => shop.sellerId === sellerId)
  }

  async getAllShops(): Promise<Shop[]> {
    return this.shops
  }

  async getShopById(shopId: string): Promise<Shop | undefined> {
    return this.shops.find((shop) => shop.id === shopId)
  }

  async createProduct(
    shopId: string,
    name: string,
    description: string,
    price: number,
    stock: number,
    category: string,
    image: string,
  ): Promise<Product> {
    const product: Product = {
      id: uuidv4(),
      shopId,
      name,
      description,
      price,
      stock,
      category,
      image,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.products.push(product)
    return product
  }

  async getProductsByShop(shopId: string): Promise<Product[]> {
    return this.products.filter((product) => product.shopId === shopId)
  }

  async getAllProducts(): Promise<Product[]> {
    return this.products
  }

  async updateProduct(id: string, updates: Partial<Product>): Promise<Product | undefined> {
    const product = this.products.find((p) => p.id === id)
    if (product) {
      Object.assign(product, updates, { updatedAt: new Date() })
    }
    return product
  }

  async createOrder(
    userId: string,
    shopId: string,
    items: { productId: string; quantity: number }[],
    total: number,
    address: string,
  ): Promise<Order> {
    const order: Order = {
      id: uuidv4(),
      userId,
      shopId,
      total,
      status: "pending",
      address,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.orders.push(order)

    // Create order items
    items.forEach((item) => {
      const orderItem: OrderItem = {
        id: uuidv4(),
        orderId: order.id,
        productId: item.productId,
        quantity: item.quantity,
        price: this.products.find((p) => p.id === item.productId)?.price || 0,
      }
      this.orderItems.push(orderItem)
    })

    await this.createDelivery(order.id)
    return order
  }

  async getOrders(userId: string): Promise<Order[]> {
    return this.orders.filter((order) => order.userId === userId)
  }

  async getOrdersByShop(shopId: string): Promise<Order[]> {
    return this.orders.filter((order) => order.shopId === shopId)
  }

  async getAllOrders(): Promise<Order[]> {
    return this.orders
  }

  async updateOrderStatus(
    orderId: string,
    status: "pending" | "processing" | "shipped" | "delivered",
  ): Promise<Order | undefined> {
    const order = this.orders.find((o) => o.id === orderId)
    if (order) {
      order.status = status
      order.updatedAt = new Date()
    }
    return order
  }

  async createReview(userId: string, productId: string, rating: number, comment: string): Promise<Review> {
    const review: Review = {
      id: uuidv4(),
      userId,
      productId,
      rating,
      comment,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.reviews.push(review)
    return review
  }

  async getReviews(productId: string): Promise<Review[]> {
    return this.reviews.filter((review) => review.productId === productId)
  }

  async createDelivery(orderId: string): Promise<Delivery> {
    const delivery: Delivery = {
      id: uuidv4(),
      orderId,
      status: "pending",
      estimatedDeliveryTime: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
      actualDeliveryTime: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    this.deliveries.push(delivery)
    return delivery
  }

  async getAllDeliveries(): Promise<Delivery[]> {
    return this.deliveries
  }

  async updateDeliveryStatus(
    deliveryId: string,
    status: "pending" | "in-transit" | "delivered",
  ): Promise<Delivery | undefined> {
    const delivery = this.deliveries.find((d) => d.id === deliveryId)
    if (delivery) {
      delivery.status = status
      delivery.updatedAt = new Date()
      if (status === "delivered") {
        delivery.actualDeliveryTime = new Date()
      }
    }
    return delivery
  }

  async createCategory(name: string, description: string | null): Promise<Category> {
    const category: Category = {
      id: uuidv4(),
      name,
      description,
    }
    this.categories.push(category)
    return category
  }

  async getCategories(): Promise<Category[]> {
    return this.categories
  }

  async addToWishlist(userId: string, productId: string): Promise<WishlistItem> {
    const wishlistItem: WishlistItem = {
      id: uuidv4(),
      userId,
      productId,
      createdAt: new Date(),
    }
    this.wishlistItems.push(wishlistItem)
    return wishlistItem
  }

  async getWishlist(userId: string): Promise<WishlistItem[]> {
    return this.wishlistItems.filter((item) => item.userId === userId)
  }

  async createCoupon(
    code: string,
    discountPercentage: number,
    validFrom: Date,
    validUntil: Date,
    usageLimit: number,
  ): Promise<Coupon> {
    const coupon: Coupon = {
      id: uuidv4(),
      code,
      discountPercentage,
      validFrom,
      validUntil,
      usageLimit,
      usageCount: 0,
    }
    this.coupons.push(coupon)
    return coupon
  }

  async getCoupon(code: string): Promise<Coupon | undefined> {
    return this.coupons.find((coupon) => coupon.code === code)
  }
}

export const db = new DB()

