"use client"

import type React from "react"
import { useState, useEffect, createContext, useContext } from "react"
import { jwtDecode } from "jwt-decode"
import { SignJWT, jwtVerify } from "jose"
import Cookies from "js-cookie"

type User = {
  id: string
  name: string
  email: string
  isSeller?: boolean
  isAdmin?: boolean
}

type AuthContextType = {
  user: User | null
  login: (email: string, password: string) => Promise<void>
  register: (name: string, email: string, password: string) => Promise<void>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    const token = Cookies.get("token")
    if (token) {
      try {
        const decodedToken = jwtDecode<User>(token)
        setUser(decodedToken)
      } catch (error) {
        console.error("Invalid token:", error)
        Cookies.remove("token")
      }
    }
  }, [])

  const login = async (email: string, password: string) => {
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    })
    if (!response.ok) {
      throw new Error("Login failed")
    }
    const { token, user } = await response.json()
    Cookies.set("token", token, { expires: 7 }) // Set cookie to expire in 7 days
    setUser(user)
  }

  const register = async (name: string, email: string, password: string) => {
    const response = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password }),
    })
    if (!response.ok) {
      throw new Error("Registration failed")
    }
    await login(email, password)
  }

  const logout = () => {
    Cookies.remove("token")
    setUser(null)
  }

  return <AuthContext.Provider value={{ user, login, register, logout }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

export async function generateToken(payload: any): Promise<string> {
  const secret = new TextEncoder().encode(process.env.JWT_SECRET)
  const token = await new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret)
  return token
}

export async function verifyToken(token: string): Promise<any> {
  const secret = new TextEncoder().encode(process.env.JWT_SECRET)
  const { payload } = await jwtVerify(token, secret)
  return payload
}

