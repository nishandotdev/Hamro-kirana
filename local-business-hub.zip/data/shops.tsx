export const shops = [
  { id: 1, name: "Fresh Harvest Kirana", category: "Organic Produce", image: "/organic-shop.jpg" },
  { id: 2, name: "Spice Paradise", category: "Spices & Condiments", image: "/spice-shop.jpg" },
  { id: 3, name: "Green Leaf Grocers", category: "Fresh Vegetables", image: "/vegetable-shop.jpg" },
  { id: 4, name: "Daily Needs Store", category: "General Grocery", image: "/general-store.jpg" },
  { id: 5, name: "Fruit Haven", category: "Fresh Fruits", image: "/fruit-shop.jpg" },
  { id: 6, name: "Dairy Delight", category: "Dairy Products", image: "/dairy-shop.jpg" },
]

